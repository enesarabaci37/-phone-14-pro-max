Attribute VB_Name = "OtomatikDizme"
Option Explicit

' Betikler panelinden �al��t�r�n: OtomatikDizme > Baslat
Public Sub Baslat()
    frmDizme.Show vbModeless
End Sub
